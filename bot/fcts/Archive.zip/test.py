#!/usr/bin/env python
#coding=utf-8

from fcts import admin,utilities
import discord,datetime,asyncio,random, re

from html.parser import HTMLParser


async def test(client,message):
    #p = MyParser()
    #p.feed(message.content)
    #await message.channel.send("Lien trouvé : "+str(p.output_list))
    r = re.compile(r"(https?://)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)/?")
    s = re.match(r,message.content)
    if s==None:
        await message.channel.send("Aucun lien trouvé")
    else:
        await message.channel.send(s.group(0))
    
class MyParser(HTMLParser):
    def __init__(self, output_list=None):
        HTMLParser.__init__(self)
        if output_list is None:
            self.output_list = []
        else:
            self.output_list = output_list
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.output_list.append(dict(attrs).get('href'))

    
    
