# -*- coding: utf-8 -*-

import re, requests, discord

class Entity:
    """Classe qui stocke toutes les informations d'une entité, en vue de la réutiliser plus tard"""
    def __init__(self,Name="",ID="",Type="",PV=0,PA=0,XP=0,Biomes=[],Dimensions=[0,0,0],Version="1.0",Img="",url=""):
        self.Name = Name
        self.ID = ID
        self.Type=Type
        self.PV = PV
        self.PA = PA
        self.XP = XP
        self.Biomes = Biomes
        self.Dimensions = Dimensions
        self.Version = Version
        self.Img = Img
        self.Url = url


async def send_entity(ID="",name="",channel=None):
    """Fonction qui envoie un embed d'une entité à partir de son nom/ID"""
    if ID=="":
        item = name
    else:
        item = ID
    E = main(item,"Entité")
    if E==None:
        await channel.send("Recherche invalide")
        return
    embed = discord.Embed(title=E.Name, colour=discord.Colour(0x4741d), url=E.Url)
    if E.Img != None and E.Img != "":
        embed.set_thumbnail(url=E.Img)
    embed.add_field(name="ID", value=str(E.ID), inline=False)
    embed.add_field(name="Type", value=E.Type, inline=True)
    embed.add_field(name="Expérience à la mort", value=str(E.XP), inline=True)
    embed.add_field(name="Points de vie", value=str(E.PV), inline=True)
    embed.add_field(name="Points d'attaque", value=str(E.PA), inline=True)
    if E.Dimensions != [0,0,0]:
        Dim = "Largeur: {d[0]}\nLongueur: {d[1]}\nHauteur: {d[2]}"
        embed.add_field(name="Dimensions", value=Dim.format(d=E.Dimensions), inline=False)
    if len(E.Biomes)>0:
        embed.add_field(name="Biomes de prédilection", value=", ".join(E.Biomes), inline=True)
    else:
        embed.add_field(name="Biomes de prédilection", value="Aucun", inline=True)
    
    embed.set_footer(text="Ajouté à la version "+E.Version)    
    await channel.send(embed=embed)
    del E

def main(item=None,Type=None):
    """Fonction qui crée un objet de type Entity/Block à partir d'un nom/ID et de son Type"""
    Type = Type.lower()
    code = search(item) #code de la page de recherche
    if code==None:
        print("(mc2) Page de recherche introuvable")
    link = search_link(code,Type)
    if link==None:
        print("(mc2) recherche invalide")
        return None
    link = "http://fr-minecraft.net/"+link
    code = url_to_html(link) #code de la page de l'item
    if Type=="entité":
        E = search_entity(code)
        E.Url = link
    #elif Type=="item"
    else:
        print("(mc2) non entité - crash")
        E = None
    return E #On renvoie l'objet


def url_to_html(url):
    """Fonction qui renvoie le code html d'une page à partir de son url"""
    try:
        mystr = requests.get(url).text
    except UnicodeDecodeError:
        print("(mc2) error latin-1")
        mystr = requests.get(url).content.decode("utf-8")
    return mystr

def search(item):
    """Fonction qui renvoie le code de la page de recherche à partir de l'item recherché"""
    p = "http://fr-minecraft.net/recherche.php?search="+"+".join(item.split(" "))
    p = url_to_html(p)
    return p


def search_link(string,Type=None):
    """Fonction qui recherche les liens des items depuis le code de la page de recherche"""
    matches = re.findall(r"<td class='id'><a[^>]+>([^<]+)",string)
    links = re.findall(r"<a href=\"([^\"]+)\"  class=\"content_link \">Voir la fiche complète</a>",string)
    if Type==None:
        return links[0]
    else:
        for m in matches:
            if m.lower() == Type.lower():
                return links[matches.index(m)]


def search_entity(string):
    """Fonction qui récupère toutes les infos sur une entité à partir du code html de sa page, et crée un objet Entity"""
    PVs = PAs = 0
    try:
        img = "http://fr-minecraft.net/"+re.search(r"<img src=\"([^\"]+)\" class=\"img\" alt=[^>]+>",string).group(1)
    except AttributeError:
        img =  ""
        pass
    matches = re.finditer(r"<u>(.+)</u>(?:[^>]+)><img[^>]+title=\"([^\"]+)",string,re.MULTILINE)
    if matches != None:
        for match in matches:
            if match.group(1)=="Points de vie :":
                PVs = match.group(2)
            elif match.group(1)=="Points d'attaque :":
                PAs = match.group(2)
    IDs = []
    try:
        for matchNum,match in enumerate(re.finditer(r"<p class=\"identifiant\"><b>([^<]+)</b>([^<]+)",string,re.MULTILINE)):
            IDs.append(match.group(1)+" "+match.group(2))
    except AttributeError:
        pass
    try:
        Type = re.search(r"<u>Type :</u> <span style=\"color: red;\">([^<]+)</span>",string).group(1)
    except AttributeError:
        Type = "Inconnu"
        pass
    try:
        XPs = re.search(r"<u>Experience :</u> <img [^>]+> (\d)<br/>",string).group(1)
    except AttributeError:
        XPs = 0
        pass
    Bioms = []
    for matchNum,match in enumerate(re.finditer(r"<li><img [^>]+ /> <a [^>]+>([^<]+)</a>",string)):
        Bioms.append(match.group(1))
    Dimensions = [0,0,0]
    try:
        r = re.search(r"<div class=\"dimensions\"><[^>]+>Dimensions :</span> <br/>\s*<ul>\s*<li>[^<\d]+([\d|.]+)</li>\s*<li>[^<\d]+([\d|.]+)</li>\s*<li>[^<\d]+([\d|.]+)",string)
        Dimensions = []
        for group in r.groups():
            Dimensions.append(float(group))
    except AttributeError:
        pass
    if len(Dimensions)<3:
        Dimensions = [0,0,0]
    try:
        V = re.search(r"<div class=\"version\">[^<]+<br/><[^>]+>([^<]+)</a>",string).group(1)
    except AttributeError:
        V ="Introuvable"
    Names = re.search(r"<h3>(.+)<span>",string,re.MULTILINE)
    if Names != None:
        Names = Names.group(1)
    else:
        Names = "Introuvable"
    En = Entity(Name=Names,ID="\n".join(IDs),Type=Type,PV=PVs,PA=PAs,XP=XPs,Biomes=Bioms,Dimensions=Dimensions,Version=V,Img=img)
    return En


def global_search(string):
    """2-3 tests useless"""
    matches = re.finditer(regex, string, re.MULTILINE)
    for matchNum, match in enumerate(matches):
        matchNum = matchNum + 1
        
        print ("Match {matchNum} was found at {start}-{end}: {match}".format(matchNum = matchNum, start = match.start(), end = match.end(), match = match.group()))
        
        for groupNum in range(0, len(match.groups())):
            groupNum = groupNum + 1
            
            print ("Group {groupNum} found at {start}-{end}: {group}".format(groupNum = groupNum, start = match.start(groupNum), end = match.end(groupNum), group = match.group(groupNum)))

