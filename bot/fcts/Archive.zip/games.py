#!/usr/bin/env python
#coding=utf-8

import asyncio,random

nothing = "<:_nothing:446782476375949323>"  #emoji de vide absolu

#schéma de la grille
morpion_schema = """
{nothing}    A{nothing}B{nothing}C

1{nothing}{A[1]}   {B[1]}   {C[1]}

2{nothing}{A[2]}   {B[2]}   {C[2]}

3{nothing}{A[3]}   {B[3]}   {C[3]}
"""

async def morpion(client,message):
    """Fonction principale, avec boucle et tout"""
    await message.channel.send("Que le combat commence ! Entrez le numéro de case pour y placer un pion ! (A1,B3...)")
    Grille = [
        ["A",":grey_question:",":grey_question:",":grey_question:"],
        ["B",":grey_question:",":grey_question:",":grey_question:"],
        ["C",":grey_question:",":grey_question:",":grey_question:"]
        ]
    continuer = True
    msg1 = msg2 = None
    while continuer:  #tant que la partie est en cours
        try:
            if msg1 != None:  #ancienne grille envoyée
                await msg1.delete()
            if msg2 != None:  #ancienne réponse du joueur
                await msg2.delete()
        except:
            pass
        msg1 = await message.channel.send(morpion_schema.format(nothing=nothing,A=Grille[0],B=Grille[1],C=Grille[2]))  #On envoie la grille
        msg2 = await wait_msg(client,message.author,message.channel)   #On attend la réponse du joueur
        player_case = ""
        if msg2 == None:  #Si il y a eu une erreur (réponse pas assez rapide par exemple)
            return
        case = msg2.content.upper()  #case jouée par le joueur
        if case[0] not in ["A","B","C"] or case[1] not in ["1","2","3"]:  
            await message.channel.send("Oups, syntaxe invalide")
            pass
        changement = False
        for l in Grille:
            if case[0]==l[0]:  #On vérifie la ligne jouée (A,B,C)
                i=0
                for c in l:
                    if c==":grey_question:" and str(i)==case[1]:  #Si la case jouée est libre
                        Grille[Grille.index(l)][i] = ":large_blue_circle:"
                        changement = True
                        break
                    elif c!=":grey_question:" and str(i)==case[1]:  #Si la case jouée n'est pas libre
                        await message.channel.send("Cette case a déjà été jouée")
                        break
                    i+=1
        if changement:  #Si la case a bien été jouée
            if morpion_winner(Grille,":large_blue_circle:"):  #Si le joueur a gagné
                await message.channel.send(morpion_schema.format(nothing=nothing,A=Grille[0],B=Grille[1],C=Grille[2])+"\nVous avez gagné ! Bravo :tada:")
                continuer = False
            else:  #On fait jouer le bot
                Grille = playing_morpion(Grille)
            if Grille==None:  #Si le bot a bug, ou qu'aucune case n'est disponible
                continuer=False
            elif morpion_winner(Grille,":red_circle:"):  #Si le bot a gagné
                await message.channel.send(morpion_schema.format(nothing=nothing,A=Grille[0],B=Grille[1],C=Grille[2])+"\nDommage ! Vous avez perdu :smirk:")
                continuer = False
    #Après la boucle
    await message.channel.send("Fin du match !") 
                    

def playing_morpion(gril):
    """On fait jouer le bot"""
    i = 0
    for l in gril:  #On parcours les colonnes (A,B,C)
        if l.count(":red_circle:")>=2 and ":grey_question:" in l: #Si il y a possibilité de gagner
            gril[i][l.index(":grey_question:")] = ":red_circle:"  #on place le jeton au dernier endroit libre
            return gril
        i+=1
    i=0
    for l in gril:  #On parcours les colonnes (A,B,C)
        if l.count(":large_blue_circle:")>=2 and ":grey_question:" in l: #Si le joueur a possibilité de gagner
            gril[i][l.index(":grey_question:")] = ":red_circle:"   #on place le jeton au dernier endroit libre
            return gril
        i+=1
    i = 0
    for i in range(1,4):  #On parcours les lignes (de 1 à 3)
        l = [gril[0][i],gril[1][i],gril[2][i]]  #sélection de la ligne correspondante
        if l.count(":red_circle:")>=2 and ":grey_question:" in l:  #Si il y a possibilité de gagner
            gril[l.index(":grey_question:")][i] = ":red_circle:"  #on place le jeton au dernier endroit libre
            return gril
        if l.count(":large_blue_circle:")>=2 and ":grey_question:" in l: #Si le joueur a possibilité de gagner
            gril[l.index(":grey_question:")][i] = ":red_circle:"  #on place le jeton au dernier endroit libre
            return gril
    l = [gril[0][1],gril[1][2],gril[2][3]]  #diagonale A1-B2-C3
    if l.count(":red_circle:")>=2 and ":grey_question:" in l:  #Si il y a possibilité de gagner
        gril[l.index(":grey_question:")][l.index(":grey_question:")+1] = ":red_circle:"  #on place le jeton au dernier endroit libre
        return gril
    if l.count(":large_blue_circle:")>=2 and ":grey_question:" in l: #Si le joueur a possibilité de gagner
        gril[l.index(":grey_question:")][l.index(":grey_question:")+1] = ":red_circle:"  #on place le jeton au dernier endroit libre
        return gril
    l = [gril[0][3],gril[1][2],gril[2][1]]  #diagonale A3-B2-C1
    if l.count(":red_circle:")>=2 and ":grey_question:" in l:  #Si il y a possibilité de gagner
        gril[l.index(":grey_question:")][l.index(":grey_question:")+1] = ":red_circle:"  #on place le jeton au dernier endroit libre
        return gril
    if l.count(":large_blue_circle:")>=2 and ":grey_question:" in l: #Si le joueur a possibilité de gagner
        gril[l.index(":grey_question:")][l.index(":grey_question:")+1] = ":red_circle:"  #on place le jeton au dernier endroit libre
        return gril
    for i in range(30):  #On teste au hasard d'autres positions libres, si aucun choix stratégique n'est possible
        c1 = random.randint(0,2)
        c2 = random.randint(1,3)
        if gril[c1][c2] == ":grey_question:":
            print("jeu random")
            gril[c1][c2] = ":red_circle:"
            return gril
    print("(morpion) Error")  #Si le bot n'a pas joué
    return None


def morpion_winner(gril,symbol):
    """Regarde si un symbole (rond bleu/rouge) a remporté la partie"""
    for l in gril:  #Pour chaque colonne (A,B,C)
        print("(morpion) 1",l)
        if l.count(symbol)==3:
            print("Victoire 1")
            return True
    for i in range(1,4):  #Pour chaque ligne (1,2,3)
        l = [gril[0][i],gril[1][i],gril[2][i]]
        print("(morpion) 2."+str(i),l)
        if l.count(symbol)==3:
            print("Victoire 2")
            return True
    l = [gril[0][1],gril[1][2],gril[2][3]]  #diagonale A1-B2-C3
    print("(morpion) 3",l)
    if l.count(symbol)==3:
        print("Victoire 3")
        return True
    l = [gril[0][3],gril[1][2],gril[2][1]]  #diagonale A3-B2-C1
    print("(morpion) 4",l)
    if l.count(symbol)==3:
        print("Victoire 4")
        return True
    return False #si rien n'a été détecté

async def wait_msg(client,author,channel,time=30.0):
    """Attend un message"""
    def check_answer(m):
        return m.author == author and m.channel==channel and len(m.content)==2
    
    msg= None
    try:
        msg = await client.wait_for('message',check=check_answer,timeout=time)
    except asyncio.TimeoutError:
        await channel.send("Vous avez trop attendu")
    except:
        await channel.send("Erreur inconnue")
        erreur()
    return msg
